<?php
session_start();
require_once 'config.php';

// CSRFトークン生成
if (empty($_SESSION['token'])) {
    $_SESSION['token'] = bin2hex(random_bytes(32));
}
$token = $_SESSION['token'];
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> | 公式サイト</title>
    <meta name="description" content="<?php echo SITE_NAME; ?>の公式サイトです。現場に強い人材提案、スピード対応で長期的な価値を提供します。">
    
    <!-- OGP Settings -->
    <meta property="og:title" content="<?php echo SITE_NAME; ?> | 公式サイト">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo SITE_URL; ?>">
    <meta property="og:image" content="<?php echo SITE_URL; ?>assets/img/ogp.jpg">
    <meta property="og:site_name" content="<?php echo SITE_NAME; ?>">
    <meta property="og:description" content="現場に強い人材提案、スピード対応で長期的な価値を提供します。">
    <meta name="twitter:card" content="summary_large_image">

    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Favicon (Emoji for simplicity) -->
    <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>✨</text></svg>">
    <!-- Google Fonts (Noto Serif JP & Cinzel for premium feel) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&family=Noto+Serif+JP:wght@300;500;700&display=swap" rel="stylesheet">
    <style>
        /* 見出しなどはCinzel(英語)と明朝体(日本語)を併用して超高級感を出す */
        body {
            font-family: 'Noto Serif JP', serif;
        }
        h1, h2, h3, .logo, .en-sub, .hero-sub, .btn, .nav-menu a {
            font-family: 'Cinzel', 'Noto Serif JP', serif;
        }
    </style>
</head>
<body>

<!-- ヘッダー -->
<header>
    <div class="container">
        <div class="logo">
            <a href="#"><?php echo SITE_NAME; ?></a>
        </div>
        <div class="menu-toggle">☰</div>
        <nav class="nav-menu">
            <ul>
                <li><a href="#news">NEWS</a></li>
                <li><a href="#features">強み</a></li>
                <li><a href="#service">事業内容</a></li>
                <li><a href="#company">会社概要</a></li>
                <li><a href="#contact" class="text-gold">お問い合わせ</a></li>
            </ul>
        </nav>
    </div>
</header>

<!-- ヒーローエリア -->
<div class="hero">
    <canvas id="hero-canvas"></canvas>
    <div class="container hero-content">
        <div class="hero-title-wrapper">
            <h1>GOLD VISION</h1>
        </div>
        <p class="en-sub">Providing unwavering value like gold</p>
        <span class="hero-sub">空前絶後の価値を、あなたに。</span>
        <div style="margin-top: 4rem;">
            <a href="#contact" class="btn btn-hero">INQUIRY NOW</a>
        </div>
        <a href="#features" class="scroll-down">
            ↓
        </a>
    </div>
</div>

<!-- News Section (Added via Admin) -->
<?php
// DB接続してニュースを取得（エラー時は無視して表示しない）
$news_items = [];
try {
    if (file_exists('db_connect.php')) {
        // 簡易的に直接PDO作成（config読み込み済み前提）
        // ※db_connect.phpはテーブル作成含むため、ここでは読み込まずに直接接続するか、includeして静かに使う
        // 今回はシンプルに、DBファイルがあれば接続して取得
        $pdo_news = new PDO('sqlite:' . __DIR__ . '/goldvision.db');
        $pdo_news->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $stmt_news = $pdo_news->query("SELECT * FROM news ORDER BY published_date DESC LIMIT 3");
        if ($stmt_news) {
            $news_items = $stmt_news->fetchAll();
        }
    }
} catch (Exception $e) {
    // Ignore error
}

if (!empty($news_items)):
?>
<section id="news" class="section" style="padding: 40px 0; background: #151515; border-bottom: 1px solid #222;">
    <div class="container">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
            <h2 class="section-title" style="margin: 0; font-size: 1.5rem; text-align: left;">NEWS</h2>
            <span style="font-size: 0.8rem; color: #888;">LATEST INFORMATION</span>
        </div>
        <ul class="news-list" style="list-style: none; padding: 0; margin: 0;">
            <?php foreach ($news_items as $item): ?>
            <li class="fade-in-up" style="border-bottom: 1px solid #333; padding: 15px 0; display: flex; flex-wrap: wrap; align-items: baseline;">
                <time style="color: var(--gold); font-family: 'Cinzel', serif; margin-right: 20px; font-weight: bold; min-width: 100px;"><?php echo htmlspecialchars($item['published_date']); ?></time>
                <span class="news-title"><?php echo htmlspecialchars($item['title']); ?></span>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>
<?php endif; ?>

<!-- 強み (Features) -->
<section id="features" class="section features">
    <div class="container">
        <h2 class="section-title fade-in-up">3つの強み</h2>
        <div class="features-grid">
            <div class="feature-card fade-in-up delay-100">
                <h3>01. 現場に強い人材提案</h3>
                <p>企業の課題を深く理解し、即戦力となる最適な人材をご提案。現場視点でのマッチングを重視しています。</p>
            </div>
            <div class="feature-card fade-in-up delay-200">
                <h3>02. スピード対応</h3>
                <p>ビジネスの機会を逃さないため、迅速なレスポンスと行動を徹底。急なご依頼にも柔軟に対応いたします。</p>
            </div>
            <div class="feature-card fade-in-up delay-300">
                <h3>03. 長期的な価値提供</h3>
                <p>一過性の関係ではなく、長期的なパートナーとして信頼関係を構築。「ゴールド」のような不変の価値を提供し続けます。</p>
            </div>
        </div>
    </div>
</section>

<!-- 事業内容 (Service) -->
<section id="service" class="section">
    <div class="container">
        <h2 class="section-title fade-in-up">事業内容</h2>
        <div class="service-list">
            <div class="service-item fade-in-up delay-100">
                <h3>人材派遣事業</h3>
                <p>必要なスキルを持った人材を、必要な期間・必要な人数、迅速に派遣いたします。</p>
            </div>
            <div class="service-item fade-in-up delay-200">
                <h3>人材紹介事業</h3>
                <p>貴社の採用課題に合わせて、最適な候補者をご紹介。採用成功まで伴走いたします。</p>
            </div>
            <div class="service-item fade-in-up delay-100">
                <h3>営業支援</h3>
                <p>新規開拓から既存顧客のフォローまで、営業活動を強力にサポートし、売上拡大に貢献します。</p>
            </div>
            <div class="service-item fade-in-up delay-200">
                <h3>業務支援・コンサルティング</h3>
                <p>業務プロセスの改善や効率化など、企業の成長を阻害する課題を解決へ導きます。</p>
            </div>
        </div>
        
        <div class="fade-in-up delay-300" style="text-align: center; margin-top: 4rem; display: flex; justify-content: center; gap: 20px; flex-wrap: wrap;">
            <div style="background: rgba(30,30,30,0.5); padding: 30px; border: 1px solid #333; max-width: 400px; backdrop-filter: blur(5px);">
                <h4 style="color: var(--gold); margin-bottom: 10px;">企業のご担当者様</h4>
                <p style="margin-bottom: 15px; font-size: 0.9rem;">人材・営業支援のご相談はお気軽にお問い合わせください。</p>
                <a href="#contact" class="btn" style="padding: 10px 20px; font-size: 0.9rem;">企業向けお問い合わせ</a>
            </div>
            <div style="background: rgba(30,30,30,0.5); padding: 30px; border: 1px solid #333; max-width: 400px; backdrop-filter: blur(5px);">
                <h4 style="color: var(--gold); margin-bottom: 10px;">お仕事をお探しの方</h4>
                <p style="margin-bottom: 15px; font-size: 0.9rem;">キャリアのご相談や求人紹介も受け付けています。</p>
                <a href="#contact" class="btn" style="padding: 10px 20px; font-size: 0.9rem;">求職者向けお問い合わせ</a>
            </div>
        </div>
    </div>
</section>

<!-- 会社概要 (Company) -->
<section id="company" class="section">
    <div class="container">
        <h2 class="section-title fade-in-up">会社概要</h2>
        <div class="company-info fade-in-up delay-100">
            <dl class="company-row">
                <dt>会社名</dt>
                <dd>
                    <?php echo COMPANY_NAME; ?><br>
                    <span style="font-size: 0.8rem; color: #888;"><?php echo SITE_NAME_EN; ?></span>
                </dd>
            </dl>
            <dl class="company-row">
                <dt>設立</dt>
                <dd><?php echo REGISTRATION_DATE; ?></dd>
            </dl>
            <dl class="company-row">
                <dt>代表者</dt>
                <dd>代表取締役社長 <?php echo CEO_NAME; ?></dd>
            </dl>
            <dl class="company-row">
                <dt>住所</dt>
                <dd>
                    〒<?php echo COMPANY_POSTAL_CODE; ?><br>
                    <?php echo COMPANY_ADDRESS; ?><br>
                    <span style="font-size: 0.8rem; color: #888; display:block; margin-top:5px;"><?php echo COMPANY_ADDRESS_EN; ?></span>
                </dd>
            </dl>
            <dl class="company-row">
                <dt>連絡先</dt>
                <dd>
                    Email: <?php echo COMPANY_EMAIL; ?><br>
                    Tel: <?php echo COMPANY_PHONE; ?>
                </dd>
            </dl>
            <dl class="company-row">
                <dt>事業内容</dt>
                <dd>
                    人材派遣事業<br>
                    人材紹介事業<br>
                    営業支援事業<br>
                    業務支援・コンサルティング<br>
                    <small style="color: #888;">※許可番号：取得準備中</small>
                </dd>
            </dl>
        </div>
    </div>
</section>

<!-- お問い合わせ (Contact) -->
<section id="contact" class="section contact">
    <div class="container">
        <h2 class="section-title fade-in-up">お問い合わせ</h2>
        <p class="fade-in-up delay-100" style="text-align: center; margin-bottom: 3rem;">
            お仕事のご依頼、ご相談などお気軽にお問い合わせください。<br>
            <span class="required">必須</span>の項目は必ずご入力ください。
        </p>
        
        <form action="form_handler.php" method="post" class="fade-in-up delay-200" style="max-width: 700px; margin: 0 auto; padding: 40px; background: rgba(20,20,20,0.5); border-radius: 8px; border: 1px solid #333;">
            <!-- CSRF Token -->
            <input type="hidden" name="token" value="<?php echo $token; ?>">
            
            <!-- Honeypot (Spam Trap) -->
            <input type="text" name="website" style="display:none;" autocomplete="off">
            
            <div class="form-group">
                <label for="type" class="required">お問い合わせ種別</label>
                <select name="type" id="type" class="form-control" required>
                    <option value="">選択してください</option>
                    <option value="企業様からのお問い合わせ">企業様からのお問い合わせ</option>
                    <option value="求職者様からのお問い合わせ">求職者様からのお問い合わせ</option>
                    <option value="その他">その他</option>
                </select>
            </div>

            <div class="form-group">
                <label for="name" class="required">お名前</label>
                <input type="text" name="name" id="name" class="form-control" placeholder="例：山田 太郎" required>
            </div>

            <div class="form-group">
                <label for="company">会社名</label>
                <input type="text" name="company" id="company" class="form-control" placeholder="例：GOLD VISION 株式会社">
            </div>

            <div class="form-group">
                <label for="phone">電話番号</label>
                <input type="tel" name="phone" id="phone" class="form-control" placeholder="例：090-1234-5678">
            </div>

            <div class="form-group">
                <label for="email" class="required">メールアドレス</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="例：info@example.com" required>
            </div>

            <div class="form-group">
                <label for="message" class="required">お問い合わせ内容</label>
                <textarea name="message" id="message" class="form-control" placeholder="ご相談内容を詳しくご記入ください。" required></textarea>
            </div>

            <div class="form-submit">
                <button type="submit" class="btn">送信する</button>
            </div>
        </form>
    </div>
</section>

<!-- フッター -->
<footer>
    <div class="container">
        <div class="footer-info">
            <p style="font-size: 1.2rem; margin-bottom: 10px;"><strong><?php echo SITE_NAME; ?></strong></p>
            <p style="font-size: 0.9rem; margin-bottom: 5px;">〒<?php echo COMPANY_POSTAL_CODE; ?> <?php echo COMPANY_ADDRESS; ?></p>
            <p style="font-size: 0.9rem;">Email: <?php echo COMPANY_EMAIL; ?></p>
        </div>
        <ul style="list-style: none; display: flex; justify-content: center; gap: 20px; margin-bottom: 20px; font-size: 0.8rem; margin-top: 20px;">
            <li><a href="privacy.php">プライバシーポリシー</a></li>
        </ul>
        <p class="copyright">&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME_EN; ?> All Rights Reserved.</p>
    </div>
</footer>

<div id="scroll-top">↑</div>

<script src="assets/js/main.js"></script>
<script src="assets/js/hero-effect.js"></script>
</body>
</html>
